<?php
session_start();
include ('connection.php');
$name = $_SESSION['user_name'];
$id = $_SESSION['id'];
if(empty($id))
{
    header("Location: index.php"); 
}

if(isset($_REQUEST['sbt-exps-btn']))
{
    $category_name = $_POST['category_name'];
    $expense_date = $_POST['expense_date'];
    $item_name = $_POST['item_name'];
    $item_price = $_POST['item_price'];
    $remark = $_POST['remarks'];

    if(!empty($expense_date))
        $expense_date = date('Y-m-d', strtotime($_POST['expense_date']));
    else 
        $expense_date = NULL;
    
    $insert_expense = mysqli_query($conn,"INSERT INTO tbl_expenses SET user_id='$id', category='$category_name', expense_date='$expense_date', item_name='$item_name', item_price='$item_price', remark='$remark'");

    if($insert_expense > 0)
    {
        echo "<script>alert('Expense added successfully.');</script>";
    }
}
?>

<?php include('include/header.php'); ?>
<div id="wrapper">
<?php include('include/side-bar.php'); ?>

<div id="content-wrapper" style="background-color: #f5f7fa; min-height: 100vh; padding: 20px;">

  <div class="container-fluid">

    <!-- Breadcrumb -->
    <ol class="breadcrumb" style="background: #fff; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
      <li class="breadcrumb-item" style="color: #003366; font-weight: 600;">
        <i class="fa fa-plus-circle" style="color: #c8102e;"></i> Add Expense
      </li>
    </ol>

    <div class="card mb-3" style="border-radius: 12px; box-shadow: 0 4px 10px rgba(0,0,0,0.08); overflow: hidden;">
      
      <div class="card-header text-white" style="background: linear-gradient(135deg, #003366, #c8102e); font-weight: 600;">
        <i class="fa fa-info-circle"></i> Submit Your Details
      </div>
             
      <form method="post" class="form-valide" style="padding: 20px;">
        <div class="card-body" style="background-color: #fff;">

          <div class="form-group row" style="margin-bottom: 20px;">
            <label class="col-lg-4 col-form-label" style="font-weight: 600;">Category <span style="color: #c8102e;">*</span></label>
            <div class="col-lg-6">
              <select class="form-control" id="category_name" name="category_name" required
                style="border: 1px solid #ccc; border-radius: 6px; padding: 8px; transition: 0.3s;">
                <option value="">Select Category</option>
                <?php 
                  $fetch_category = mysqli_query($conn, "SELECT * FROM tbl_category WHERE status=1");
                  while($row = mysqli_fetch_array($fetch_category)){
                ?>
                <option><?php echo $row['category_name']; ?></option>
                <?php } ?>
              </select>
            </div>
          </div>    

          <div class="form-group row" style="margin-bottom: 20px;">
            <label class="col-lg-4 col-form-label" style="font-weight: 600;">Date <span style="color: #c8102e;">*</span></label>
            <div class="col-lg-6">
              <input type="date" class="form-control" id="expense_date" name="expense_date" required
                style="border: 1px solid #ccc; border-radius: 6px; padding: 8px;">
            </div>
          </div>

          <div class="form-group row" style="margin-bottom: 20px;">
            <label class="col-lg-4 col-form-label" style="font-weight: 600;">Item <span style="color: #c8102e;">*</span></label>
            <div class="col-lg-6">
              <input type="text" name="item_name" id="item_name" class="form-control" placeholder="Enter Item Name" required
                style="border: 1px solid #ccc; border-radius: 6px; padding: 8px;">
            </div>
          </div>

          <div class="form-group row" style="margin-bottom: 20px;">
            <label class="col-lg-4 col-form-label" style="font-weight: 600;">Price <span style="color: #c8102e;">*</span></label>
            <div class="col-lg-6">
              <input type="number" name="item_price" id="item_price" class="form-control" placeholder="Enter Price" required
                style="border: 1px solid #ccc; border-radius: 6px; padding: 8px;">
            </div>
          </div>                                         

          <div class="form-group row" style="margin-bottom: 20px;">
            <label class="col-lg-4 col-form-label" style="font-weight: 600;">Remarks</label>
            <div class="col-lg-6">
              <textarea rows="3" name="remarks" id="remarks" class="form-control" placeholder="Enter Remarks..."
                style="border: 1px solid #ccc; border-radius: 6px; padding: 8px;"></textarea>
            </div>
          </div>

          <div class="form-group row" style="margin-top: 30px;">
            <div class="col-lg-8 ml-auto">
              <button type="submit" name="sbt-exps-btn"
                style="background: linear-gradient(135deg, #c8102e, #003366); color: #fff; border: none; padding: 10px 25px; border-radius: 8px; font-weight: 600; transition: all 0.3s ease; cursor: pointer;">
                <i class="fa fa-paper-plane"></i> Submit
              </button>
            </div>
          </div>

        </div>
      </form>
    </div>
  </div>
</div>

<a class="scroll-to-top rounded" href="#page-top"
   style="background-color: #c8102e; color: #fff; border-radius: 50%; padding: 10px;">
  <i class="fas fa-angle-up"></i>
</a>

<?php include('include/footer.php'); ?>
