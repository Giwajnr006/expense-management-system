<?php
session_start();
include('../connection.php');

$name = $_SESSION['name'] ?? '';
$id = $_SESSION['id'] ?? '';

if (empty($id)) {
    header("Location: index.php");
    exit();
}

$message = '';

if (isset($_POST['sbt-cat'])) {
    $category_name = trim($_POST['category_name']);
    $status = $_POST['status'];

    if (!empty($category_name) && isset($status)) {
        $stmt = $conn->prepare("INSERT INTO tbl_category (category_name, status) VALUES (?, ?)");
        $stmt->bind_param("si", $category_name, $status);

        if ($stmt->execute()) {
            $message = '<div class="alert alert-success fade-in">✅ Category added successfully!</div>';
        } else {
            $message = '<div class="alert alert-danger fade-in">❌ Error adding category. Please try again.</div>';
        }

        $stmt->close();
    } else {
        $message = '<div class="alert alert-warning fade-in">⚠️ Please fill all fields.</div>';
    }
}
?>
<?php include('include/header.php'); ?>
<div id="wrapper">
    <?php include('include/side-bar.php'); ?>

    <div id="content-wrapper">
        <div class="container-fluid">

            <!-- Breadcrumbs-->
            <ol class="breadcrumb">
                <li class="breadcrumb-item active">
                    <i class="fa fa-folder"></i> Add Category
                </li>
            </ol>

            <div class="card mb-3 shadow-lg border-0 rounded">
                <div class="card-header bg-gradient-primary text-white">
                    <i class="fa fa-info-circle"></i> Submit Details
                </div>

                <form method="post" class="p-4">
                    <div class="card-body">
                        <?= $message ?>

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Category Name <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="text" name="category_name" id="category_name" class="form-control" placeholder="Enter Category Name" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Status <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <select class="form-control" id="status" name="status" required>
                                    <option value="">Select Status</option>
                                    <option value="1">Active</option>
                                    <option value="0">Inactive</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row mt-4">
                            <div class="col-lg-8 ml-auto">
                                <button type="submit" name="sbt-cat" class="btn btn-gradient">Submit</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>

<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<?php include('include/footer.php'); ?>

<!-- Custom CSS for red & blue theme and animation -->
<style>
    .bg-gradient-primary {
        background: linear-gradient(45deg, #e63946, #1d3557);
    }

    .btn-gradient {
        background: linear-gradient(45deg, #e63946, #1d3557);
        color: #fff;
        border: none;
        padding: 10px 25px;
        border-radius: 25px;
        transition: 0.3s;
    }

    .btn-gradient:hover {
        transform: scale(1.05);
        background: linear-gradient(45deg, #1d3557, #e63946);
    }

    .alert {
        margin-bottom: 15px;
        border-radius: 10px;
        padding: 12px 20px;
        font-weight: 500;
        animation: fadeIn 0.6s ease-in-out;
    }

    .fade-in {
        animation: fadeIn 0.8s ease-in-out;
    }

    @keyframes fadeIn {
        from {opacity: 0; transform: translateY(-10px);}
        to {opacity: 1; transform: translateY(0);}
    }
</style>
