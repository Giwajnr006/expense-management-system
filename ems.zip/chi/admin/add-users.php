<?php
session_start();
include('../connection.php');
$name = $_SESSION['name'];
$id = $_SESSION['id'];

if (empty($id)) {
    header("Location: index.php");
    exit;
}

if (isset($_POST['sbt-usr'])) {
    $user_name = $_POST['user_name'];
    $emailid = $_POST['emailid'];
    $pwd = md5($_POST['pwd']);
    $role = $_POST['role'];
    $status = $_POST['status'];

    $insert_user = mysqli_query($conn, "INSERT INTO tbl_users (user_name, emailid, password, role, status)
                                        VALUES ('$user_name', '$emailid', '$pwd', '$role', '$status')");

    if ($insert_user) {
        echo "<script>
            setTimeout(() => {
                Swal.fire({
                    icon: 'success',
                    title: 'User Added Successfully!',
                    text: 'A new user has been added to the system.',
                    confirmButtonColor: '#0056b3'
                }).then(() => {
                    window.location.href = 'view-users.php';
                });
            }, 200);
        </script>";
    } else {
        echo "<script>
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: 'Failed to add user. Please try again.',
                confirmButtonColor: '#d93025'
            });
        </script>";
    }
}
?>

<?php include('include/header.php'); ?>
<div id="wrapper">
    <?php include('include/side-bar.php'); ?>

    <div id="content-wrapper">
        <div class="container-fluid">

            <!-- Breadcrumb -->
            <ol class="breadcrumb">
                <li class="breadcrumb-item active">
                    <i class="fa fa-user-plus"></i> Add User
                </li>
            </ol>

            <div class="card shadow-lg border-0 rounded-4 mt-4 mb-5" style="max-width: 750px; margin: auto;">
                <div class="card-header text-white" style="background: linear-gradient(90deg, #0056b3, #d93025);">
                    <h5 class="mb-0"><i class="fa fa-info-circle"></i> Submit User Details</h5>
                </div>

                <form method="post" class="p-4">
                    <div class="form-group mb-3">
                        <label><strong>User Name</strong> <span class="text-danger">*</span></label>
                        <input type="text" name="user_name" id="user_name" class="form-control form-control-lg"
                            placeholder="Enter User Name" required>
                    </div>

                    <div class="form-group mb-3">
                        <label><strong>Email</strong> <span class="text-danger">*</span></label>
                        <input type="email" name="emailid" id="emailid" class="form-control form-control-lg"
                            placeholder="Enter Email Address" required>
                    </div>

                    <div class="form-group mb-3 position-relative">
                        <label><strong>Password</strong> <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <input type="password" name="pwd" id="pwd" class="form-control form-control-lg"
                                placeholder="Enter Password" required>
                            <button type="button" class="btn btn-outline-secondary" id="togglePwd">
                                <i class="fa fa-eye"></i>
                            </button>
                        </div>
                    </div>

                    <div class="form-group mb-3">
                        <label><strong>Role</strong> <span class="text-danger">*</span></label>
                        <select class="form-control form-control-lg" id="role" name="role" required>
                            <option value="">Select Role</option>
                            <option value="1">Admin</option>
                            <option value="2">User</option>
                        </select>
                    </div>

                    <div class="form-group mb-4">
                        <label><strong>Status</strong> <span class="text-danger">*</span></label>
                        <select class="form-control form-control-lg" id="status" name="status" required>
                            <option value="">Select Status</option>
                            <option value="1">Active</option>
                            <option value="0">Inactive</option>
                        </select>
                    </div>

                    <div class="d-flex justify-content-center">
                        <button type="submit" name="sbt-usr" class="btn btn-lg text-white px-5"
                            style="background: linear-gradient(90deg, #0056b3, #d93025); border: none;">
                            <i class="fa fa-save"></i> Submit
                        </button>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>

<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<?php include('include/footer.php'); ?>

<!-- SweetAlert2 CDN -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
// Toggle password visibility
document.getElementById('togglePwd').addEventListener('click', function() {
    const pwdField = document.getElementById('pwd');
    const icon = this.querySelector('i');
    if (pwdField.type === 'password') {
        pwdField.type = 'text';
        icon.classList.replace('fa-eye', 'fa-eye-slash');
    } else {
        pwdField.type = 'password';
        icon.classList.replace('fa-eye-slash', 'fa-eye');
    }
});
</script>

<style>
/* Custom Styling for Red-Blue Theme */
.card {
    border-radius: 15px !important;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    transition: all 0.3s ease;
}
.card:hover {
    transform: translateY(-3px);
}
.form-control:focus {
    border-color: #0056b3;
    box-shadow: 0 0 5px rgba(0, 86, 179, 0.3);
}
label {
    color: #333;
}
.btn:focus {
    box-shadow: none;
}
</style>
