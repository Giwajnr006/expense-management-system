<?php
session_start();
include '../connection.php';

$name = $_SESSION['name'];
$id = $_SESSION['id'];

if (empty($id)) {
    header("Location: index.php");
    exit;
}

// Fetch total users (role = 2)
$select_user = mysqli_query($conn, "SELECT COUNT(*) FROM tbl_users WHERE role = 2");
$total_user = mysqli_fetch_row($select_user);

// Fetch total active categories
$select_category = mysqli_query($conn, "SELECT COUNT(*) FROM tbl_category WHERE status = 1");
$total_category = mysqli_fetch_row($select_category);
?>

<?php include('include/header.php'); ?>

<div id="wrapper">
    <?php include('include/side-bar.php'); ?>

    <div id="content-wrapper">
        <div class="container-fluid">

            <!-- Breadcrumb -->
            <ol class="breadcrumb">
                <li class="breadcrumb-item active">
                    <i class="fa fa-dashboard"></i> Dashboard
                </li>
            </ol>

            <div class="row">
                <!-- Total Users Card -->
                <div class="col-md-6 col-xl-4 mb-4">
                    <div class="card shadow border-left-primary h-100 py-2" style="border-left: 5px solid #0056b3;">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="mr-3">
                                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Users</div>
                                    <h4 class="mb-0 font-weight-bold text-dark counter" data-target="<?php echo $total_user[0]; ?>">0</h4>
                                </div>
                                <div class="ml-auto">
                                    <i class="fa fa-users fa-2x text-primary"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Total Categories Card -->
                <div class="col-md-6 col-xl-4 mb-4">
                    <div class="card shadow border-left-danger h-100 py-2" style="border-left: 5px solid #d93025;">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="mr-3">
                                    <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">Active Categories</div>
                                    <h4 class="mb-0 font-weight-bold text-dark counter" data-target="<?php echo $total_category[0]; ?>">0</h4>
                                </div>
                                <div class="ml-auto">
                                    <i class="fa fa-list-alt fa-2x text-danger"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<?php include('include/footer.php'); ?>

<!-- Counter Animation Script -->
<script>
document.addEventListener("DOMContentLoaded", () => {
    const counters = document.querySelectorAll('.counter');
    counters.forEach(counter => {
        counter.innerText = '0';
        const updateCounter = () => {
            const target = +counter.getAttribute('data-target');
            const current = +counter.innerText;
            const increment = target / 100; // Speed control
            if (current < target) {
                counter.innerText = Math.ceil(current + increment);
                setTimeout(updateCounter, 20);
            } else {
                counter.innerText = target;
            }
        };
        updateCounter();
    });
});
</script>

<style>
/* Red & Blue Theme Enhancements */
.card {
    border-radius: 15px;
    transition: all 0.3s ease;
}
.card:hover {
    transform: translateY(-5px);
    box-shadow: 0 4px 20px rgba(0,0,0,0.15);
}
.text-primary { color: #0056b3 !important; } /* Blue */
.text-danger { color: #d93025 !important; } /* Red */
.border-left-primary { border-left-color: #0056b3 !important; }
.border-left-danger { border-left-color: #d93025 !important; }
</style>
