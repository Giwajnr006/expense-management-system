<?php
session_start();
include('../connection.php');

// Check if user is logged in
if (empty($_SESSION['id'])) {
    header("Location: index.php");
    exit;
}

$name = $_SESSION['name'];
$admin_id = $_SESSION['id'];

// Check if category ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: view-category.php");
    exit;
}

$id = intval($_GET['id']);

// Fetch category details securely
$stmt = $conn->prepare("SELECT * FROM tbl_category WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if (!$row) {
    echo "<script>alert('Invalid category selected.'); window.location.href='view-category.php';</script>";
    exit;
}

// Handle form submission
if (isset($_POST['sv-cat'])) {
    $category_name = trim($_POST['category_name']);
    $status = $_POST['status'];

    if (!empty($category_name) && ($status == '0' || $status == '1')) {
        $update_stmt = $conn->prepare("UPDATE tbl_category SET category_name = ?, status = ? WHERE id = ?");
        $update_stmt->bind_param("sii", $category_name, $status, $id);
        $success = $update_stmt->execute();

        if ($success) {
            echo "<script>alert('Category updated successfully.'); window.location.href='view-category.php';</script>";
            exit;
        } else {
            echo "<script>alert('Error updating category. Please try again.');</script>";
        }
    } else {
        echo "<script>alert('Please fill all required fields correctly.');</script>";
    }
}
?>

<?php include('include/header.php'); ?>
<div id="wrapper">

    <?php include('include/side-bar.php'); ?>

    <div id="content-wrapper">
        <div class="container-fluid">

            <!-- Breadcrumb -->
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Edit Category</a></li>
            </ol>

            <div class="card mb-3 shadow">
                <div class="card-header bg-primary text-white">
                    <i class="fa fa-edit"></i> Edit Category Details
                </div>

                <form method="post" class="form-valide">
                    <div class="card-body">

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Category Name <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="text" name="category_name" id="category_name" class="form-control" 
                                    placeholder="Enter Category Name"
                                    value="<?php echo htmlspecialchars($row['category_name']); ?>" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Status <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <select class="form-control" id="status" name="status" required>
                                    <option value="">Select Status</option>
                                    <option value="1" <?php if ($row['status'] == 1) echo 'selected'; ?>>Active</option>
                                    <option value="0" <?php if ($row['status'] == 0) echo 'selected'; ?>>Inactive</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-lg-8 ml-auto">
                                <button type="submit" name="sv-cat" class="btn btn-primary">
                                    <i class="fa fa-save"></i> Update Category
                                </button>
                                <a href="view-category.php" class="btn btn-secondary">
                                    <i class="fa fa-arrow-left"></i> Back
                                </a>
                            </div>
                        </div>

                    </div>
                </form>
            </div>

        </div>
    </div>

</div>

<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<?php include('include/footer.php'); ?>
