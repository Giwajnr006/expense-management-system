<?php
session_start();
include ('../connection.php');
$name = $_SESSION['name'];
$id = $_SESSION['id'];
if (empty($id)) {
    header("Location: index.php");
}

$id = $_GET['id'];
$fetch_query = mysqli_query($conn, "SELECT * FROM tbl_users WHERE id='$id'");
$row = mysqli_fetch_array($fetch_query);

if (isset($_POST['sv-user'])) {
    $user_name = $_POST['user_name'];
    $emailid = $_POST['emailid'];
    $role = $_POST['role'];
    $status = $_POST['status'];

    $update_user = mysqli_query($conn, "UPDATE tbl_users SET user_name='$user_name', emailid='$emailid', role='$role', status='$status' WHERE id='$id'");

    if ($update_user > 0) {
        echo "<script>
            alert('User updated successfully.');
            window.location.href='view-users.php';
        </script>";
    }
}
?>

<?php include('include/header.php'); ?>
<div id="wrapper">
    <?php include('include/side-bar.php'); ?>

    <div id="content-wrapper">
        <div class="container-fluid">
            
            <!-- Breadcrumbs -->
            <ol class="breadcrumb bg-light shadow-sm rounded">
                <li class="breadcrumb-item active">
                    <i class="fa fa-user-edit"></i> Edit User
                </li>
            </ol>

            <!-- Edit Form Card -->
            <div class="card shadow-lg border-0 rounded-lg mt-4 mb-5">
                <div class="card-header text-white" style="background: linear-gradient(90deg, #cc0000, #0044cc);">
                    <i class="fa fa-info-circle"></i> Edit User Details
                </div>

                <form method="post" class="p-4">
                    <div class="form-group">
                        <label for="user_name" class="font-weight-bold">User Name <span class="text-danger">*</span></label>
                        <input type="text" name="user_name" id="user_name" class="form-control rounded-pill shadow-sm" placeholder="Enter user name" required value="<?php echo $row['user_name']; ?>">
                    </div>

                    <div class="form-group">
                        <label for="emailid" class="font-weight-bold">Email Address <span class="text-danger">*</span></label>
                        <input type="email" name="emailid" id="emailid" class="form-control rounded-pill shadow-sm" placeholder="Enter email address" required value="<?php echo $row['emailid']; ?>">
                    </div>

                    <div class="form-group">
                        <label for="role" class="font-weight-bold">Role <span class="text-danger">*</span></label>
                        <select class="form-control rounded-pill shadow-sm" id="role" name="role" required>
                            <option value="">Select Role</option>
                            <option value="1" <?php if($row['role'] == 1) echo 'selected'; ?>>Admin</option>
                            <option value="2" <?php if($row['role'] == 2) echo 'selected'; ?>>User</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="status" class="font-weight-bold">Status <span class="text-danger">*</span></label>
                        <select class="form-control rounded-pill shadow-sm" id="status" name="status" required>
                            <option value="">Select Status</option>
                            <option value="1" <?php if($row['status'] == 1) echo 'selected'; ?>>Active</option>
                            <option value="0" <?php if($row['status'] == 0) echo 'selected'; ?>>Inactive</option>
                        </select>
                    </div>

                    <div class="text-center mt-4">
                        <button type="submit" name="sv-user" class="btn btn-lg text-white shadow-sm rounded-pill" 
                            style="background: linear-gradient(90deg, #cc0000, #0044cc); border: none;">
                            <i class="fa fa-save"></i> Save Changes
                        </button>
                    </div>
                </form>
            </div>

        </div>
    </div>

    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>
</div>

<?php include('include/footer.php'); ?>
