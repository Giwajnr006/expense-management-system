<!DOCTYPE html>
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">

  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <title>Newgate University Expense Management System</title>

  <!-- Custom fonts -->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Custom styles -->
  <link href="css/sb-admin.css" rel="stylesheet">
  <link href="css/custom_style.css?ver=2.0" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.css" rel="stylesheet" />
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <link href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.9/themes/base/jquery-ui.css" rel="stylesheet" />

  <style>
    /* ===== Navbar Red-Blue Theme ===== */
    .navbar {
      background: linear-gradient(90deg, #1d3557, #e63946);
      box-shadow: 0 3px 10px rgba(0, 0, 0, 0.15);
      height: 65px;
      font-family: 'Poppins', sans-serif;
      letter-spacing: 0.3px;
    }

    .navbar h4 {
      color: #ffffff;
      font-size: 1.25rem;
      font-weight: 600;
      margin: 0;
      padding-left: 10px;
    }

    .navbar .btn-link {
      color: #ffffff;
      transition: transform 0.2s ease, color 0.3s ease;
    }

    .navbar .btn-link:hover {
      color: #f1faee;
      transform: scale(1.15);
    }

    .navbar .form-inline span {
      color: #f1faee;
      font-weight: 500;
      margin-right: 20px;
    }

    .navbar-nav .nav-item .nav-link {
      color: #ffffff !important;
      transition: color 0.3s ease, transform 0.2s ease;
    }

    .navbar-nav .nav-item .nav-link:hover {
      color: #f1faee !important;
      transform: scale(1.1);
    }

    .dropdown-menu {
      border-radius: 10px;
      border: none;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      margin-top: 10px;
    }

    .dropdown-menu .dropdown-item {
      font-weight: 500;
      color: #1d3557;
      transition: all 0.3s ease;
    }

    .dropdown-menu .dropdown-item:hover {
      background: linear-gradient(45deg, #e63946, #1d3557);
      color: #ffffff;
      border-radius: 6px;
    }

    /* Mobile friendly */
    @media (max-width: 768px) {
      .navbar h4 {
        font-size: 1rem;
      }
      .navbar .form-inline span {
        font-size: 0.9rem;
      }
    }
  </style>
</head>

<body id="page-top">

  <!-- Top Navbar -->
  <nav class="navbar navbar-expand navbar-dark static-top">

    <h4><i class="fa fa-university"></i> Newgate University | Expense Management System</h4>

    <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle">
      <i class="fas fa-bars"></i>
    </button>

    <!-- Welcome Text -->
    <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
      <span>Welcome, <?php echo htmlspecialchars($name); ?></span>
    </form>

    <!-- User Menu -->
    <ul class="navbar-nav ml-auto ml-md-0">
      <li class="nav-item dropdown no-arrow">
        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
           data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-user-circle fa-lg"></i>
        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
          <a class="dropdown-item" href="logout.php">
            <i class="fa fa-sign-out-alt"></i> Logout
          </a>
        </div>
      </li>
    </ul>

  </nav>
