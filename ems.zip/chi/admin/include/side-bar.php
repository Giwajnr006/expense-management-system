<!-- Sidebar -->
<ul class="sidebar navbar-nav" style="background: linear-gradient(180deg, #1d3557, #e63946); min-height: 100vh; color: white;">
  
  <!-- Dashboard -->
  <li class="nav-item active">
    <a class="nav-link sidebar-link" href="dashboard.php">
      <i class="fas fa-fw fa-tachometer-alt"></i>
      <span>Dashboard</span>
    </a>
  </li>

  <!-- Manage Category -->
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle sidebar-link" href="#" id="categoryDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="fa fa-list-alt"></i>
      <span>Manage Category</span>
    </a>
    <div class="dropdown-menu custom-dropdown" aria-labelledby="categoryDropdown">
      <a class="dropdown-item" href="add-category.php">Add Category</a>
      <a class="dropdown-item" href="view-category.php">View Category</a>
    </div>
  </li>

  <!-- Manage Users -->
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle sidebar-link" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="fa fa-user"></i>
      <span>Manage Users</span>
    </a>
    <div class="dropdown-menu custom-dropdown" aria-labelledby="userDropdown">
      <a class="dropdown-item" href="add-users.php">Add Users</a>
      <a class="dropdown-item" href="view-users.php">View Users</a>
    </div>
  </li>

</ul>

<!-- Sidebar Custom CSS -->
<style>
  .sidebar {
    font-family: "Poppins", sans-serif;
    font-size: 15px;
    border-right: 2px solid rgba(255, 255, 255, 0.1);
  }

  .sidebar-link {
    color: #fff !important;
    display: flex;
    align-items: center;
    padding: 12px 20px;
    transition: all 0.3s ease;
  }

  .sidebar-link:hover {
    background: rgba(255, 255, 255, 0.15);
    transform: translateX(5px);
    border-radius: 8px;
  }

  .sidebar-link i {
    margin-right: 10px;
    color: #f1faee;
    font-size: 16px;
  }

  .nav-item.active .sidebar-link {
    background: rgba(255, 255, 255, 0.25);
    font-weight: 600;
    border-left: 4px solid #f1faee;
  }

  .custom-dropdown {
    background: #f8f9fa;
    border: none;
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.15);
    margin-left: 15px;
  }

  .custom-dropdown .dropdown-item {
    color: #1d3557;
    transition: background 0.3s ease, color 0.3s ease;
    border-radius: 8px;
  }

  .custom-dropdown .dropdown-item:hover {
    background: linear-gradient(45deg, #e63946, #1d3557);
    color: white;
  }
</style>
