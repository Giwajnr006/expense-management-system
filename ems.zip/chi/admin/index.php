<?php
session_start();
include '../connection.php';

if (isset($_REQUEST['login_btn'])) {
    $email = $_POST['email'];
    $pwd = md5($_POST['pwd']);

    $select_query = mysqli_query($conn, "SELECT id, user_name FROM tbl_users WHERE emailid='$email' AND password='$pwd' AND role=1 AND status=1");
    $rows = mysqli_num_rows($select_query);

    if ($rows > 0) {
        $username = mysqli_fetch_row($select_query);
        $_SESSION['id'] = $username[0];
        $_SESSION['name'] = $username[1];
        header("Location: dashboard.php");
        exit();
    } else {
        echo "<script>alert('Invalid email or password.');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Admin Login | Expense Management System</title>

<!-- Fonts and CSS -->
<link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
<link href="css/sb-admin.css" rel="stylesheet">
<link href="css/custom_style.css?ver=1.1" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style>
/* === Red & Blue Theme Login Page === */
body {
  background: linear-gradient(135deg, #b30000 0%, #003366 100%);
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: 'Segoe UI', sans-serif;
}

.card-login {
  max-width: 400px;
  width: 100%;
  border: none;
  border-radius: 10px;
  box-shadow: 0 8px 25px rgba(0, 0, 0, 0.25);
  overflow: hidden;
}

.card-header {
  background: linear-gradient(90deg, #b30000 0%, #003366 100%);
  color: #fff;
  text-align: center;
  font-weight: 600;
  padding: 1.5rem;
  font-size: 1.5rem;
  letter-spacing: 1px;
  border-bottom: 3px solid #fff;
}

.card-header img {
  width: 60px;
  margin-bottom: 8px;
  background: #fff;
  border-radius: 8px;
  padding: 4px;
}

.card-body {
  background-color: #fff;
  padding: 2rem;
}

.form-control {
  border-radius: 5px;
  border: 1px solid #ccc;
}

.form-control:focus {
  border-color: #003366;
  box-shadow: 0 0 5px rgba(0, 51, 102, 0.5);
}

.btn-primary {
  background: linear-gradient(90deg, #b30000 0%, #003366 100%);
  border: none;
  border-radius: 5px;
  font-weight: bold;
  letter-spacing: 0.5px;
  transition: all 0.3s ease-in-out;
}

.btn-primary:hover {
  background: linear-gradient(90deg, #cc0000 0%, #004080 100%);
  transform: scale(1.02);
}
</style>
</head>

<body>

  <div class="card card-login">
    <div class="card-header">
      <img src="images.png" alt="Logo"><br>
      NEWGATE UNIVERSITY<br>Expense Management System
    </div>

    <div class="card-body">
      <form name="login" method="post" action="">
        <div class="form-group">
          <label for="inputEmail"><i class="fa fa-envelope"></i> Email Address</label>
          <input type="email" id="inputEmail" class="form-control" name="email" placeholder="Enter your email" required autofocus>
        </div>
        <div class="form-group">
          <label for="inputPassword"><i class="fa fa-lock"></i> Password</label>
          <input type="password" id="inputPassword" class="form-control" name="pwd" placeholder="Enter your password" required>
        </div>
        <input type="submit" class="btn btn-primary btn-block" name="login_btn" value="Login">
      </form>
    </div>
  </div>

</body>
</html>
