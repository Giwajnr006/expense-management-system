(function($) {
    'use strict'

    $('#jstree_basic').jstree();













})(jQuery);