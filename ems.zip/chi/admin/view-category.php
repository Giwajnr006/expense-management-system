<?php
session_start();
include ('../connection.php');
$name = $_SESSION['name'];
$id = $_SESSION['id'];
if (empty($id)) {
    header("Location: index.php");
    exit();
}
?>
<?php include('include/header.php'); ?>
<div id="wrapper">

  <?php include('include/side-bar.php'); ?>

  <div id="content-wrapper">

    <div class="container-fluid">

      <!-- Breadcrumb -->
      <ol class="breadcrumb shadow-sm" style="background: #fff; border-left: 4px solid #003366;">
        <li class="breadcrumb-item active">
          <i class="fa fa-list-alt text-danger"></i> View Categories
        </li>
      </ol>

      <!-- Category Card -->
      <div class="card mb-3 border-0 shadow-sm">
        <div class="card-header text-white d-flex justify-content-between align-items-center"
             style="background: linear-gradient(90deg, #b30000 0%, #003366 100%);">
          <div><i class="fa fa-info-circle"></i> Category Details</div>
          <img src="images.png" alt="Logo" style="height: 35px; background: #fff; padding: 3px; border-radius: 6px;">
        </div>

        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
              <thead class="text-white" style="background: linear-gradient(90deg, #b30000 0%, #003366 100%);">
                <tr>
                  <th>S/N</th>
                  <th>Category Name</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php
                if (isset($_GET['ids'])) {
                    $id = $_GET['ids'];
                    mysqli_query($conn, "DELETE FROM tbl_category WHERE id='$id'");
                }

                $select_query = mysqli_query($conn, "SELECT * FROM tbl_category ORDER BY id DESC");
                $sn = 1;
                while ($row = mysqli_fetch_array($select_query)) {
                ?>
                  <tr>
                    <td><?php echo $sn++; ?></td>
                    <td><?php echo htmlspecialchars($row['category_name']); ?></td>
                    <td>
                      <?php echo ($row['status'] == 1)
                          ? '<span class="badge badge-success">Active</span>'
                          : '<span class="badge badge-danger">Inactive</span>'; ?>
                    </td>
                    <td>
                      <a href="edit-category.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-outline-primary">
                        <i class="fa fa-pencil"></i> Edit
                      </a>
                      <a href="view-category.php?ids=<?php echo $row['id']; ?>" onclick="return confirmDelete();" class="btn btn-sm btn-outline-danger">
                        <i class="fa fa-trash"></i> Delete
                      </a>
                    </td>
                  </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>

  </div>
</div>

<a class="scroll-to-top rounded" href="#page-top">
  <i class="fas fa-angle-up"></i>
</a>

<?php include('include/footer.php'); ?>

<script>
function confirmDelete() {
  return confirm('Are you sure you want to delete this category?');
}
</script>

<style>
/* === Red & Blue Theme Enhancements === */
.card-header img {
  height: 35px;
  margin-left: 10px;
}
.table-hover tbody tr:hover {
  background-color: #f9f9f9;
}
.btn-outline-primary:hover {
  background-color: #003366;
  color: #fff;
}
.btn-outline-danger:hover {
  background-color: #b30000;
  color: #fff;
}
.badge-success {
  background-color: #006400 !important;
}
.badge-danger {
  background-color: #b30000 !important;
}
</style>
