<?php
session_start();
include ('../connection.php');
$name = $_SESSION['name'];
$id = $_SESSION['id'];
if (empty($id)) {
    header("Location: index.php");
    exit();
}
?>

<?php include('include/header.php'); ?>
<div id="wrapper">

  <?php include('include/side-bar.php'); ?>

  <div id="content-wrapper">

    <div class="container-fluid">

      <!-- Breadcrumb -->
      <ol class="breadcrumb shadow-sm" style="background: #fff; border-left: 4px solid #003366;">
        <li class="breadcrumb-item active">
          <i class="fa fa-users text-danger"></i> View Users
        </li>
      </ol>

      <!-- Card Section -->
      <div class="card mb-3 border-0 shadow-sm">
        <div class="card-header text-white d-flex justify-content-between align-items-center"
             style="background: linear-gradient(90deg, #b30000 0%, #003366 100%);">
          <div><i class="fa fa-info-circle"></i> User Details</div>
          <img src="images.png" alt="Logo" style="height: 35px; background:#fff; padding:3px; border-radius:6px;">
        </div>

        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
              <thead class="text-white" style="background: linear-gradient(90deg, #b30000 0%, #003366 100%);">
                <tr>
                  <th>S/N</th>
                  <th>User Name</th>
                  <th>Email</th>
                  <th>Role</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php
                if (isset($_GET['ids'])) {
                    $id = $_GET['ids'];
                    mysqli_query($conn, "DELETE FROM tbl_users WHERE id='$id'");
                }

                $select_query = mysqli_query($conn, "SELECT * FROM tbl_users ORDER BY id DESC");
                $sn = 1;
                while ($row = mysqli_fetch_array($select_query)) {
                ?>
                  <tr>
                    <td><?php echo $sn++; ?></td>
                    <td><?php echo htmlspecialchars($row['user_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['emailid']); ?></td>
                    <td>
                      <?php echo ($row['role'] == 1) ? '<span class="badge badge-primary">Admin</span>' : '<span class="badge badge-secondary">User</span>'; ?>
                    </td>
                    <td>
                      <?php echo ($row['status'] == 1)
                          ? '<span class="badge badge-success">Active</span>'
                          : '<span class="badge badge-danger">Inactive</span>'; ?>
                    </td>
                    <td>
                      <a href="edit-user.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-outline-primary">
                        <i class="fa fa-pencil"></i> Edit
                      </a>
                      <a href="view-users.php?ids=<?php echo $row['id']; ?>" onclick="return confirmDelete();" class="btn btn-sm btn-outline-danger">
                        <i class="fa fa-trash"></i> Delete
                      </a>
                    </td>
                  </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<a class="scroll-to-top rounded" href="#page-top">
  <i class="fas fa-angle-up"></i>
</a>

<?php include('include/footer.php'); ?>

<script>
function confirmDelete() {
  return confirm('Are you sure you want to delete this user?');
}
</script>

<style>
/* === Red & Blue Theme Enhancements === */
.card-header img {
  height: 35px;
  margin-left: 10px;
}
.table-hover tbody tr:hover {
  background-color: #f9f9f9;
}
.btn-outline-primary:hover {
  background-color: #003366;
  color: #fff;
}
.btn-outline-danger:hover {
  background-color: #b30000;
  color: #fff;
}
.badge-primary {
  background-color: #003366 !important;
}
.badge-secondary {
  background-color: #b30000 !important;
}
</style>
