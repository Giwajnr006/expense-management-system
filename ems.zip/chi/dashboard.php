<?php
session_start();
$name = $_SESSION['user_name'];
$id = $_SESSION['id'];
include 'connection.php';
if (empty($name)) {
    header("Location: index.php");
}

$total_expense = mysqli_query($conn, "SELECT SUM(item_price) AS expense FROM tbl_expenses WHERE user_id='$id'");
$total_expense = mysqli_fetch_row($total_expense);

$today_expense = mysqli_query($conn, "SELECT SUM(item_price) AS expense FROM tbl_expenses WHERE user_id='$id' AND expense_date=CURDATE()");
$today_expense = mysqli_fetch_assoc($today_expense);

$yesterday_expense = mysqli_query($conn, "SELECT SUM(item_price) AS expense FROM tbl_expenses WHERE user_id='$id' AND expense_date=CURDATE()-1");
$yesterday_expense = mysqli_fetch_assoc($yesterday_expense);

$week_expense = mysqli_query($conn, "SELECT SUM(item_price) AS expense FROM tbl_expenses WHERE WEEK(expense_date)=WEEK(NOW()) AND user_id='$id'");
$week_expense = mysqli_fetch_assoc($week_expense);

$month_expense = mysqli_query($conn, "SELECT SUM(item_price) AS expense FROM tbl_expenses WHERE MONTH(expense_date)=MONTH(CURRENT_DATE()) AND YEAR(expense_date)=YEAR(CURRENT_DATE()) AND user_id='$id'");
$month_expense = mysqli_fetch_assoc($month_expense);

$year_expense = mysqli_query($conn, "SELECT SUM(item_price) AS expense FROM tbl_expenses WHERE YEAR(expense_date)=YEAR(CURDATE()) AND user_id='$id'");
$year_expense = mysqli_fetch_assoc($year_expense);

include('include/header.php');
?>

<div id="wrapper" style="background: #f5f6fa; font-family: 'Poppins', sans-serif; color: #333; min-height: 100vh;">

  <?php include('include/side-bar.php'); ?>

  <div id="content-wrapper" style="padding: 30px;">
    <div class="container-fluid">

      <!-- Top Header -->
      <div style="background: linear-gradient(90deg, #002147, #c0392b); color: #fff; padding: 20px 25px; border-radius: 10px; margin-bottom: 25px; box-shadow: 0 4px 10px rgba(0,0,0,0.2);">
        <h2 style="margin: 0;">Welcome, <?php echo ucfirst($name); ?> 👋</h2>
        <p style="margin: 5px 0 0; font-size: 14px;">Expense Management Dashboard</p>
      </div>

      <!-- Expense Summary Cards -->
      <div style="display: flex; flex-wrap: wrap; gap: 20px; justify-content: center;">

        <?php
        $cards = [
          ["Total Expense", $total_expense[0], "#002147", "#fff", "total"],
          ["Today's Expense", $today_expense['expense'], "#c0392b", "#fff", "today"],
          ["Yesterday's Expense", $yesterday_expense['expense'], "#00509e", "#fff", "yesterday"],
          ["This Week Expense", $week_expense['expense'], "#e74c3c", "#fff", "week"],
          ["This Month Expense", $month_expense['expense'], "#004aad", "#fff", "month"],
          ["This Year Expense", $year_expense['expense'], "#b22222", "#fff", "year"]
        ];

        foreach ($cards as $card) {
          list($title, $amount, $bgColor, $textColor, $idName) = $card;
        ?>
          <div style="flex: 1 1 30%; background: <?php echo $bgColor; ?>; color: <?php echo $textColor; ?>; border-radius: 12px; padding: 25px; min-width: 270px; box-shadow: 0 6px 15px rgba(0,0,0,0.2); transition: transform 0.3s; text-align:left;">
            <div style="display: flex; align-items: center;">
              <div style="background: rgba(255,255,255,0.15); border-radius: 50%; width: 60px; height: 60px; display: flex; align-items: center; justify-content: center; font-size: 24px; margin-right: 15px;">
                <i class="fa fa-money"></i>
              </div>
              <div>
                <h4 style="margin: 0; font-size: 18px; color: #fff;"><?php echo $title; ?></h4>
                <strong id="<?php echo $idName; ?>_amt" data-target="<?php echo $amount ? $amount : 0; ?>" style="font-size: 22px;">₦0.00</strong>
              </div>
            </div>
          </div>
        <?php } ?>

      </div>
    </div>
  </div>
</div>

<!-- Scroll To Top -->
<a href="#page-top" style="position: fixed; bottom: 25px; right: 25px; background: #c0392b; color: #fff; border-radius: 50%; width: 45px; height: 45px; display: flex; align-items: center; justify-content: center; text-decoration: none; box-shadow: 0 4px 10px rgba(0,0,0,0.3); transition: background 0.3s;">
  <i class="fas fa-angle-up"></i>
</a>

<script>
  // Animate all expense counters
  document.querySelectorAll("[id$='_amt']").forEach(el => {
    const target = parseFloat(el.getAttribute("data-target")) || 0;
    let count = 0;
    const duration = 1500; // total animation time (ms)
    const step = target / (duration / 16); // update ~60fps

    const update = () => {
      count += step;
      if (count < target) {
        el.innerText = "₦" + Math.floor(count).toLocaleString();
        requestAnimationFrame(update);
      } else {
        el.innerText = "₦" + target.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
      }
    };
    update();
  });
</script>

<?php include('include/footer.php'); ?>
