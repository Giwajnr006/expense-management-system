<?php
session_start();
include('connection.php');

if (empty($_SESSION['id'])) {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['id'];
$name = $_SESSION['user_name'];

// Validate expense ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: view-expense.php");
    exit();
}

$expense_id = intval($_GET['id']);
$fetch_query = mysqli_query($conn, "SELECT * FROM tbl_expenses WHERE id='$expense_id' AND user_id='$user_id'");
$row = mysqli_fetch_array($fetch_query);

if (!$row) {
    echo "<script>alert('Expense not found!'); window.location.href='view-expense.php';</script>";
    exit();
}

if (isset($_POST['save-exps-btn'])) {
    $category_name = mysqli_real_escape_string($conn, $_POST['category_name']);
    $expense_date = !empty($_POST['expense_date']) ? date('Y-m-d', strtotime($_POST['expense_date'])) : NULL;
    $item_name = mysqli_real_escape_string($conn, $_POST['item_name']);
    $item_price = floatval($_POST['item_price']);
    $remark = mysqli_real_escape_string($conn, $_POST['remarks']);

    $update_expense = mysqli_query($conn, "
        UPDATE tbl_expenses 
        SET 
            category='$category_name', 
            expense_date='$expense_date', 
            item_name='$item_name', 
            item_price='$item_price', 
            remark='$remark' 
        WHERE id='$expense_id' AND user_id='$user_id'
    ");

    if ($update_expense) {
        echo "<script>
            alert('Expense updated successfully.');
            window.location.href='view-expense.php';
        </script>";
        exit();
    } else {
        echo "<script>alert('Error updating expense. Please try again.');</script>";
    }
}
?>

<?php include('include/header.php'); ?>
<div id="wrapper">
<?php include('include/side-bar.php'); ?>

<div id="content-wrapper">
  <div class="container-fluid">

    <!-- Breadcrumb -->
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="#">Edit Expense</a></li>
    </ol>

    <div class="card mb-3 shadow-lg border-0">
      <div class="card-header bg-gradient text-white" style="background: linear-gradient(90deg, #c62828, #1565c0);">
        <i class="fa fa-edit"></i> Edit Expense Details
      </div>

      <form method="post" class="p-4">
        <div class="form-group row">
          <label class="col-lg-4 col-form-label">Category <span class="text-danger">*</span></label>
          <div class="col-lg-6">
            <select class="form-control" name="category_name" required>
              <option value="">Select Category</option>
              <?php 
              $fetch_category = mysqli_query($conn, "SELECT * FROM tbl_category");
              while ($cat = mysqli_fetch_array($fetch_category)) {
                $selected = ($cat['category_name'] == $row['category']) ? 'selected' : '';
                echo "<option $selected>{$cat['category_name']}</option>";
              }
              ?>
            </select>
          </div>
        </div>

        <div class="form-group row">
          <label class="col-lg-4 col-form-label">Date <span class="text-danger">*</span></label>
          <div class="col-lg-6">
            <input type="text" class="form-control" name="expense_date" required 
              value="<?php echo htmlspecialchars($row['expense_date']); ?>">
          </div>
        </div>

        <div class="form-group row">
          <label class="col-lg-4 col-form-label">Item <span class="text-danger">*</span></label>
          <div class="col-lg-6">
            <input type="text" name="item_name" class="form-control" required 
              value="<?php echo htmlspecialchars($row['item_name']); ?>">
          </div>
        </div>

        <div class="form-group row">
          <label class="col-lg-4 col-form-label">Price <span class="text-danger">*</span></label>
          <div class="col-lg-6">
            <input type="number" name="item_price" step="0.01" class="form-control" required 
              value="<?php echo htmlspecialchars($row['item_price']); ?>">
          </div>
        </div>

        <div class="form-group row">
          <label class="col-lg-4 col-form-label">Remarks</label>
          <div class="col-lg-6">
            <textarea rows="3" name="remarks" class="form-control"><?php echo htmlspecialchars($row['remark']); ?></textarea>
          </div>
        </div>

        <div class="form-group row">
          <div class="col-lg-8 ml-auto">
            <button type="submit" name="save-exps-btn" id="saveBtn" class="btn btn-primary px-4">
              <i class="fa fa-save"></i> Save Changes
            </button>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>
</div>

<a class="scroll-to-top rounded" href="#page-top">
  <i class="fas fa-angle-up"></i>
</a>

<?php include('include/footer.php'); ?>

<script>
// Add loading effect to Save button
document.getElementById('saveBtn').addEventListener('click', function() {
  this.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Saving...';
});
</script>
