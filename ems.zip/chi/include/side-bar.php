<!-- Sidebar -->
<ul class="sidebar navbar-nav" style="
    background: linear-gradient(180deg, #b30000 0%, #003366 100%);
    min-height: 100vh;
    box-shadow: 2px 0 8px rgba(0,0,0,0.2);
    color: #fff;
">
  <li class="nav-item active" style="border-left: 4px solid #fff;">
    <a class="nav-link" href="dashboard.php" style="color: #fff; font-weight: 600;">
      <i class="fas fa-fw fa-tachometer-alt" style="color: #fff;"></i>
      <span>Dashboard</span>
    </a>
  </li>

  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button"
       data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
       style="color: #fff; font-weight: 500;">
      <i class="fa fa-money" style="color: #fff;"></i>
      <span>Manage Expense</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown" 
         style="background-color: #003366; border: none; border-radius: 6px;">
      <a class="dropdown-item" href="add-expense.php"
         style="color: #fff; background-color: transparent;">Add Expense</a>
      <a class="dropdown-item" href="view-expense.php"
         style="color: #fff; background-color: transparent;">View Expense</a>
    </div>
  </li>

  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="reportsDropdown" role="button"
       data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
       style="color: #fff; font-weight: 500;">
      <i class="fa fa-file" style="color: #fff;"></i>
      <span>Manage Reports</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="reportsDropdown"
         style="background-color: #003366; border: none; border-radius: 6px;">
      <a class="dropdown-item" href="view-reports.php"
         style="color: #fff; background-color: transparent;">View Reports</a>
    </div>
  </li>
</ul>

<style>
  /* Hover effects */
  .sidebar .nav-link:hover,
  .sidebar .dropdown-item:hover {
    background-color: rgba(255, 255, 255, 0.15) !important;
    color: #fff !important;
  }

  .sidebar .dropdown-menu .dropdown-item:hover {
    background-color: #b30000 !important;
  }

  /* Active state */
  .sidebar .nav-item.active {
    background-color: rgba(255, 255, 255, 0.15);
  }

  .sidebar .dropdown-menu {
    transition: all 0.3s ease-in-out;
  }
</style>
