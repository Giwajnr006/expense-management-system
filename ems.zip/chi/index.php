<?php
session_start();
include('connection.php');

if (isset($_REQUEST['login_btn'])) {
    $uname = $_POST['email'];
    $upwd = md5($_POST['pwd']);

    $select_query = mysqli_query($conn, "SELECT user_name, id FROM tbl_users WHERE emailid='$uname' AND password='$upwd' AND role=2 AND status=1");
    $username = mysqli_fetch_row($select_query);

    if (!empty($username)) {
        $_SESSION['user_name'] = $username[0];
        $_SESSION['id'] = $username[1];
    }

    $rows = mysqli_num_rows($select_query);

    if ($rows > 0) {
        header("Location: dashboard.php");
    } else {
        echo "<script>alert('You have entered wrong emailid or password.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Newgate University | Expense Management System</title>

<link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body style="background: linear-gradient(120deg, #002147, #003366); font-family: 'Poppins', sans-serif; color: #fff; margin: 0; padding: 0;">

  <div style="display: flex; justify-content: center; align-items: center; height: 100vh;">
    <div style="background: #fff; color: #333; width: 400px; border-radius: 15px; box-shadow: 0 4px 20px rgba(0,0,0,0.3); padding: 30px;">
      
      <div style="text-align: center; margin-bottom: 20px;">
        <h2 style="color: #002147; margin-bottom: 5px;">Newgate University</h2>
        <p style="color: #777; font-size: 14px;">Expense Management System</p>
        <hr style="border: 1px solid #ccc;">
        <h3 style="color: #d35400;">User Login</h3>
      </div>
      
      <form name="login" method="post" action="">
        <div style="margin-bottom: 15px;">
          <label for="inputEmail" style="font-weight: bold; display: block; margin-bottom: 5px;">Email Address</label>
          <input type="email" id="inputEmail" name="email" required autofocus
                 style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 8px; font-size: 15px; outline: none;">
        </div>

        <div style="margin-bottom: 20px;">
          <label for="inputPassword" style="font-weight: bold; display: block; margin-bottom: 5px;">Password</label>
          <input type="password" id="inputPassword" name="pwd" required
                 style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 8px; font-size: 15px; outline: none;">
        </div>

        <input type="submit" name="login_btn" value="Login"
               style="width: 100%; background: #002147; color: #fff; border: none; padding: 12px; border-radius: 8px; font-size: 16px; font-weight: bold; cursor: pointer; transition: background 0.3s;">
        <input type="hidden" name="submitted" value="true">
      </form>

      <div style="text-align: center; margin-top: 15px;">
        <p style="font-size: 13px; color: #777;">© <?php echo date("Y"); ?> Newgate University. All Rights Reserved.</p>
      </div>
    </div>
  </div>

</body>
</html>
