<?php
session_start();
include ('connection.php');

$name = $_SESSION['user_name'];
$id = $_SESSION['id'];
if (empty($id)) {
    header("Location: index.php"); 
    exit();
}
?>

<?php include('include/header.php'); ?>
<div id="wrapper">

<?php include('include/side-bar.php'); ?>

<div id="content-wrapper">
  <div class="container-fluid">

    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="#">View Expense</a>
      </li>
    </ol>

    <div class="card mb-3">
      <div class="card-header">
        <i class="fa fa-info-circle"></i>
        View Your Details
      </div>

      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
              <tr>
                <th>S.No.</th>
                <th>Category</th>
                <th>Date</th>
                <th>Item</th>
                <th>Price</th>
                <th>Remark</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php
              // Handle delete action
              if (isset($_GET['ids'])) {
                  $del_id = $_GET['ids'];
                  mysqli_query($conn, "DELETE FROM tbl_expenses WHERE id='$del_id'");
                  echo "<script>window.location.href='view-expense.php';</script>"; // auto-refresh after delete
              }

              // Fetch user expenses
              $select_query = mysqli_query($conn, "SELECT * FROM tbl_expenses WHERE user_id='$id' ORDER BY expense_date DESC");
              $sn = 1;
              while ($row = mysqli_fetch_array($select_query)) {
                  $date = date('d M Y', strtotime($row['expense_date']));
              ?>
                <tr>
                  <td><?php echo $sn; ?></td>
                  <td><?php echo htmlspecialchars($row['category']); ?></td>
                  <td><?php echo $date; ?></td>
                  <td><?php echo htmlspecialchars($row['item_name']); ?></td>
                  <td class="animated-price"><?php echo $row['item_price']; ?></td>
                  <td><?php echo htmlspecialchars($row['remark']); ?></td>
                  <td>
                    <a href="edit-expense.php?id=<?php echo $row['id']; ?>">
                      <i class="fa fa-pencil m-r-5"></i> Edit
                    </a>
                    |
                    <a href="view-expense.php?ids=<?php echo $row['id']; ?>" onclick="return confirmDelete()">
                      <i class="fa fa-trash-o m-r-5"></i> Delete
                    </a>
                  </td>
                </tr>
              <?php 
              $sn++; 
              } 
              ?>
            </tbody>
          </table>
        </div>
      </div>                   
    </div>
  </div>
</div>

<a class="scroll-to-top rounded" href="#page-top">
  <i class="fas fa-angle-up"></i>
</a>

<?php include('include/footer.php'); ?>

<script type="text/javascript">
function confirmDelete() {
    return confirm('Are you sure you want to delete this Expense?');
}

// Animate numbers from 0 to actual price
document.addEventListener('DOMContentLoaded', function() {
  const priceCells = document.querySelectorAll('.animated-price');
  priceCells.forEach(cell => {
    const targetValue = parseFloat(cell.textContent) || 0;
    let current = 0;
    const duration = 1000; // 1 second
    const increment = targetValue / (duration / 16);

    cell.textContent = '0';

    const counter = setInterval(() => {
      current += increment;
      if (current >= targetValue) {
        cell.textContent = targetValue.toLocaleString(undefined, {minimumFractionDigits: 2});
        clearInterval(counter);
      } else {
        cell.textContent = current.toLocaleString(undefined, {minimumFractionDigits: 2});
      }
    }, 16);
  });
});
</script>
