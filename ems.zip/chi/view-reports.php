<?php
session_start();
include ('connection.php');
$name = $_SESSION['user_name'];
$id = $_SESSION['id'];
if(empty($name)) {
    header("Location: index.php"); 
}
?>

<?php include('include/header.php'); ?>
<div id="wrapper" style="background:#f8f9fa; font-family:'Poppins',sans-serif; color:#333; min-height:100vh;">

  <?php include('include/side-bar.php'); ?>

  <div id="content-wrapper" style="padding:25px;">

    <div class="container-fluid">

      <!-- Header -->
      <div style="background:linear-gradient(90deg,#002147,#c0392b); color:#fff; padding:20px; border-radius:10px; margin-bottom:25px; box-shadow:0 4px 10px rgba(0,0,0,0.2);">
        <h3 style="margin:0;">View Reports</h3>
        <p style="margin:5px 0 0; font-size:14px;">Filter your expense history by date and category.</p>
      </div>

      <!-- Search Form -->
      <form method="post" style="background:#fff; border-radius:10px; padding:20px; box-shadow:0 3px 10px rgba(0,0,0,0.1); margin-bottom:25px;">
        <div class="form-group row" style="align-items:center;">
          
          <label class="col-lg-1 col-form-label" for="from" style="font-weight:600;">From</label>
          <div class="col-lg-3">
            <input type="text" class="form-control" id="from_date" name="from_date" placeholder="Select Date" required 
              style="border-radius:6px; border:1px solid #ccc; padding:8px;">
          </div>

          <label class="col-lg-1 col-form-label" for="to" style="font-weight:600;">To</label>
          <div class="col-lg-3">
            <input type="text" class="form-control" id="to_date" name="to_date" placeholder="Select Date" required
              style="border-radius:6px; border:1px solid #ccc; padding:8px;">
          </div>

          <div class="col-lg-3">
            <select class="form-control" id="category_name" name="category_name" required
              style="border-radius:6px; border:1px solid #ccc; padding:8px;">
              <option value="">Select Category</option>
              <?php 
                $fetch_category = mysqli_query($conn, "select * from tbl_category");
                while($row = mysqli_fetch_array($fetch_category)) {
              ?>
                <option value="<?php echo $row['category_name']; ?>"><?php echo $row['category_name']; ?></option>
              <?php } ?>
            </select>
          </div>

          <div class="col-lg-2">
            <button type="submit" name="srh-btn" 
              style="background:linear-gradient(90deg,#002147,#c0392b); border:none; color:#fff; font-weight:600; padding:10px 20px; border-radius:6px; transition:0.3s; width:100%;">
              Search
            </button>
          </div>

        </div>
      </form>

      <!-- Report Table -->
      <div class="card mb-3" style="border:none; border-radius:10px; box-shadow:0 3px 12px rgba(0,0,0,0.1);">
        <div class="card-header" style="background:linear-gradient(90deg,#002147,#c0392b); color:#fff; font-weight:600; font-size:16px; border-top-left-radius:10px; border-top-right-radius:10px;">
          <i class="fa fa-info-circle"></i> View Your Expense Details
        </div>
        <div class="card-body" style="background:#fff; border-bottom-left-radius:10px; border-bottom-right-radius:10px;">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0" 
              style="text-align:center; border-radius:8px; overflow:hidden;">
              <thead style="background:#002147; color:#fff;">
                <tr>
                  <th>S.No.</th>
                  <th>Category</th>
                  <th>Expense Date</th>
                  <th>Item Name</th>
                  <th>Item Price (₦)</th>
                </tr>
              </thead>
              <tbody style="background:#fff;">
                <?php
                if(isset($_REQUEST['srh-btn'])) {
                  $from_date = date('Y-m-d', strtotime($_POST['from_date']));
                  $to_date = date('Y-m-d', strtotime($_POST['to_date']));
                  $cat = $_POST['category_name'];

                  $search_query = mysqli_query($conn, "select * from tbl_expenses where expense_date>='$from_date' and expense_date<='$to_date' and category='$cat' and user_id='$id'");
                  $sn = 1;
                  while($rows = mysqli_fetch_array($search_query)) { ?>
                    <tr style="background:#fdfdfd;">
                      <td><?php echo $sn; ?></td>
                      <td><?php echo $rows['category']; ?></td>
                      <td><?php echo $rows['expense_date']; ?></td>
                      <td><?php echo $rows['item_name']; ?></td>
                      <td style="color:#c0392b; font-weight:600;"><?php echo number_format($rows['item_price'],2); ?></td>
                    </tr>
                <?php $sn++; } 
                } else {
                  $select_query = mysqli_query($conn, "select * from tbl_expenses where user_id='$id' order by id");
                  $sn = 1;
                  while($row = mysqli_fetch_array($select_query)) { ?>
                    <tr style="background:#fdfdfd;">
                      <td><?php echo $sn; ?></td>
                      <td><?php echo $row['category']; ?></td>
                      <td><?php echo $row['expense_date']; ?></td>
                      <td><?php echo $row['item_name']; ?></td>
                      <td style="color:#c0392b; font-weight:600;"><?php echo number_format($row['item_price'],2); ?></td>
                    </tr>
                <?php $sn++; } }?>
              </tbody>
            </table>
          </div>
        </div>
      </div>

    </div>

  </div>
</div>

<!-- Scroll To Top -->
<a href="#page-top" style="position:fixed; bottom:25px; right:25px; background:#c0392b; color:#fff; border-radius:50%; width:45px; height:45px; display:flex; align-items:center; justify-content:center; text-decoration:none; box-shadow:0 4px 10px rgba(0,0,0,0.3); transition:background 0.3s;">
  <i class="fas fa-angle-up"></i>
</a>

<?php include('include/footer.php'); ?>
